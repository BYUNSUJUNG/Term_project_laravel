@extends('layouts.template')
@section('title')
게시글 리스트
@endsection

@section('view')

		<div class="container">
			<table class="table">
			<tr>
				<th>제목</th>
				<td><?=$msg["Title"]?></td>
			</tr>
			<tr>
				<th>작성자</th>
				<td><?= $msg["Writer"]?></td>
			</tr>
			<tr>
				<th>작성일지</th>
				<td><?= $msg["Regtime"]?></td>
			</tr>
			<tr>
				<th>조회수</th>
				<td><?= $msg["Hits"]?></td>
			</tr>
			<tr>
				<th>내용</th>
				<td><?= $msg["Content"]?></td>
			</tr>
			</table>
		</div>
	
		<div class="container">

			<input type="button" class="btn btn-primary"
			 onclick="location.href='board'" value="목록보기">
			<form action="modify">
				<input type="button" class="btn btn-primary"
				onclick="location.href='modify_form?num=<?=$num?>'" value="수정">
			</form>
			<form action="delete" method="post">
			 	@crsf
			 	<input type="hidden" name="num" value="{{$msg['num']}}">
				<input type="button" class="btn btn-primary"
				 onclick="delReq(1)" value="삭제">
			</form>
		</div>
@endsection
