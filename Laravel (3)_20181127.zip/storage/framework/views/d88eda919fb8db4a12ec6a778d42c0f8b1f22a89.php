<?php $__env->startSection('title'); ?>
	게시글 리스트
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('bbs/companySidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="container">		
        <h2>회사연혁</h2>
        <hr>
        <!-- <img class="button_left" src="images/companyHistory.jpg" alt="피자" /> -->
    </div>


<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>