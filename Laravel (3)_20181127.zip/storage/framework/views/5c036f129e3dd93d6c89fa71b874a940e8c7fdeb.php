
<div class="list-group">
    <button type="button" class="list-group-item list-group-item-action active">
        Customer
    </button>
    <a href="<?php echo e(route('companyInformation')); ?>"><button type="button" class="list-group-item list-group-item-action">회사소개</button></a>
    <a href="<?php echo e(route('companyHistory')); ?>"><button type="button" class="list-group-item list-group-item-action">회사연혁</button></a>
    <a href="<?php echo e(route('companyLocation')); ?>"><button type="button" class="list-group-item list-group-item-action">회사위치</button></a>
</div>