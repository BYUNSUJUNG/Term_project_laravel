<?php $__env->startSection('title'); ?>
	게시글 리스트
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('bbs/menuSidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-lg-3 col-md-4 col-xs-6 thumb">
        <a class="thumbnail" href="menuBurgerView/<?php echo e($menus->id); ?>">
        <img height="200" width="200" src="/img/<?php echo e($menus->file); ?>"/>
        
        </a>
    </div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<?php echo e($menu->links()); ?>

		<article>
			<div class="menu">
				<img height="350" width="350" src="/img/<?php echo e($menuId->file); ?>"/>
			</div>
			<div> 
				<h1><?php echo e($menuId->title); ?></h1>
				<?php echo e($menuId->content); ?>

			</div>
			
	<div class="container">
  		<h2>게시글 상세 정보</h2>
  	</div>	


	<div class="container">
		<table class="table">
			<tr> 
				<th>제목</th>
				<td><?php echo e($menuId->title); ?></td>
			</tr>	
			<tr> 
				<th>작성자</th>
				<td><?php echo e($menuId->writer); ?></td>
			</tr>	
			<tr> 
				<th>작성일시</th>
				<td><?php echo e($menuId->created_at); ?></td>				
			</tr>	
			<tr> 
				<th>내용</th>
				<td><?php echo e($menuId->content); ?></td>				
			</tr>				
		</table>	
	</div>	
	<div class="container">
		<div class="row">
			<a href="<?php echo e(route('menuBurger')); ?>">목록보기</a>
			<a href="<?php echo e(route('modify_form',$menuId->id)); ?>">글수정</a>
			<a href="<?php echo e(route('delete',$menuId->id)); ?>">글삭제</a>
		</div>	
	</div>
    
<!-- jQuery -->
<script src="/js/jquery.js"></script>

<!-- Bootstrap Core JavaScript -->
<script src="/js/bootstrap.min.js"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>