<?php $__env->startSection('title'); ?>
	게시글 리스트
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('bbs/customerSidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>


	<table class="table table-hover">
		<tr>
			<th>번호</th>
			<th>제목</th>
			<th>작성자</th>
			<th>작성일시</th>
			<th>조회수</th>
		</tr>	
		<?php $__currentLoopData = $customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customers): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><?php echo e($customers->id); ?></td>
				<td>
					<a href="view/<?php echo e($customers->id); ?>">
						<?php echo e($customers->title); ?>						
					</a>		
				</td>
				<td><?php echo e($customers->writer); ?></td>
				<td><?php echo e($customers->created_at); ?></td>
			</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	

	</table>	
	<?php echo e($customer->links()); ?>

	<a href="<?php echo e(route('customer_write_form')); ?>">글작성</a>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>