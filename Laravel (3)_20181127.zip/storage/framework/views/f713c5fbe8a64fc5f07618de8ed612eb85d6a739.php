<?php echo $__env->make('bbs/header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="content">
    hi
</div>

