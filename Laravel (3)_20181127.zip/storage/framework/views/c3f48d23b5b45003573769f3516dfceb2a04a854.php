
<div class="list-group">
    <button type="button" class="list-group-item list-group-item-action active">
        Customer
    </button>
    <a href="<?php echo e(route('customerNotices')); ?>"><button type="button" class="list-group-item list-group-item-action">공지사항</button></a>
    <a href="<?php echo e(route('customerCounselingService')); ?>"><button type="button" class="list-group-item list-group-item-action">1:1문의</button></a>
    <a href="<?php echo e(route('customerAdvertisingSchedule')); ?>"><button type="button" class="list-group-item list-group-item-action">광고일정</button></a>
</div>

