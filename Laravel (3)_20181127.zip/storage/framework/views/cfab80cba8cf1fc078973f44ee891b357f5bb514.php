
<div class="list-group">
    <button type="button" class="list-group-item list-group-item-action active">
        Store
    </button>
    <a href="<?php echo e(route('storeNationwideFranchise')); ?>"><button type="button" class="list-group-item list-group-item-action">전국 가맹점 찾기</button></a>
    <a href="<?php echo e(route('storeNewFranchise')); ?>"><button type="button" class="list-group-item list-group-item-action">신규 오픈매장</button></a>
    <a href="<?php echo e(route('storeGallery')); ?>"><button type="button" class="list-group-item list-group-item-action">사진 갤러리</button></a>
</div>