<div class="menu_sidebar">
    <button type="button" class="list-group-item list-group-item-action active">
        MENU
    </button>
    <a href="<?php echo e(route('menuBurger')); ?>"><button type="button" class="list-group-item list-group-item-action">버거 메뉴</button></a>
    <a href="<?php echo e(route('menuChicken')); ?>"><button type="button" class="list-group-item list-group-item-action">치킨 메뉴</button></a>
    
    <a href="<?php echo e(route('menuDrink')); ?>"><button type="button" class="list-group-item list-group-item-action">음료류</button></a>
    <a href="<?php echo e(route('menuSide')); ?>"><button type="button" class="list-group-item list-group-item-action">사이드 메뉴</button></a>
</div>
