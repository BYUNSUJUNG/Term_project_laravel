<?php $__env->startSection('title'); ?>
	글 상세보기 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>



	<div class="container">
  		<h2>게시글 상세 정보</h2>
  	</div>	


	<div class="container">
		<table class="table">
			<tr> 
				<th>제목</th>
				<td><?php echo e($menu->title); ?></td>
			</tr>	
			<tr> 
				<th>작성자</th>
				<td><?php echo e($menu->writer); ?></td>
			</tr>	
			<tr> 
				<th>작성일시</th>
				<td><?php echo e($menu->created_at); ?></td>				
			</tr>	
			<tr> 
				<th>내용</th>
				<td><?php echo e($menu->content); ?></td>				
			</tr>				
		</table>	

	</div>	
	<div class="container">
		<div class="row">
			<input type="button" class="btn btn-primary" 
				onclick="location.href='bbs?page=<?php echo e($menu->page); ?>'" value="목록보기">
			<input type="button" class="btn btn-success" 
				onclick="location.href='modify_form/<?php echo e($menu->id); ?>'" value="수정">
			<a href="<?php echo e(route('delete',$menu->id)); ?>">글삭제</a>
		</div>	
	</div>	

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>