<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class customer extends Model
{
    protected $filelable = ['customer_board','writer','title','file','content'];
}
