<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class UserController extends Controller
{
   public function __construct() {
	   return $this->middleware('guest'); // 게스트만 호출가능(로그인x사용자)
   }

   public function create() {

   }
}
