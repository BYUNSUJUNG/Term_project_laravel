<?php

return [
    'name'=>'이름',
    'password' => '비번',
    'email'=>'이메일',
    'register' => '등록', 

    'passwordconform' => '암호 확인',
];
?>