<?php

return [
    'name'=>'Name',
    'password' => 'Password',
    'email'=>'e-mail',
    'register' => 'Register', 
    
    'passwordconform' => 'Password Conform',
];
?>