
<div class="list-group">
    <button type="button" class="list-group-item list-group-item-action active">
        Customer
    </button>
    <a href="{{route('customerNotices')}}"><button type="button" class="list-group-item list-group-item-action">공지사항</button></a>
    <a href="{{route('customerCounselingService')}}"><button type="button" class="list-group-item list-group-item-action">1:1문의</button></a>
    <a href="{{route('customerAdvertisingSchedule')}}"><button type="button" class="list-group-item list-group-item-action">광고일정</button></a>
</div>

