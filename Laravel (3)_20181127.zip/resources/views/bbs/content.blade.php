@include('bbs/header')

<div class="content">
    hi
</div>

