@extends('layouts.template')

@section('title')
	게시글 리스트
@endsection

@section('content')
@include('bbs/companySidebar')
  
    <div class="container">		
        <h2>회사소개</h2>
        <hr>
        <!-- 
        <img class="button_left" src="images/companyInformation1.jpg" alt="피자" />
        <img class="button_left" src="images/companyInformation2.jpg" alt="피자" />
        <img class="button_left" src="images/companyInformation3.jpg" alt="피자" />
        -->
    </div>
