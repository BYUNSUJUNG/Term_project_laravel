<?php //1701140_변수정 ?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>글 수정 페이지</title>
		<!--Latest compiled and minified CSS -->
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
		<!-- jQuery library -->
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
		<!-- Popper JS -->
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
		<!-- Latest compiled JavaScript -->
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
	</head>
	<body> 
    <?php
				/*
					1. 클라이언트 송신한 num값을 읽는다.
					2. 그 값으로 해당하는 게시글을 읽는다
					3. 그 정보를 이용해 html을 동적으로 생성한다.
				*/
	
				require_once("boardDao.php"); // java inport와 유사함, require_once를 하면 한번만 읽어옴
        		require_once("MemberDao.php");
				require_once("tools.php");
				
				session_start(); // 세션 시작
				
				$name = isset($_SESSION["name"])?$_SESSION["name"]:"";
				$writer = requestValues("writer");
				/*
				if(!$name) { // $name 값이 없을 때
					errorBack("로그인부터 하시오");
					/* 
						tools.php의 함수, 메세지 창을 띄우고 전 페이지로 이동함
						alert('<?= $msg ?>'); // 창 띄움
						history.back(); 
					
				} else { // $name 값이 있을 때
					if($name!=$writer) // name가 writer와 다를 때
						errorBack("권한이 없습니다.");
				}
			*/
				$id = isset($_SESSION["id"])?$_SESSION["id"]:"";
				$mdao = new MemberDao(); // 생성자 실행 -> db연결됨
				$member = $mdao->getMember($id); // 아이디가 프라이머리키라서 레코드가 하나뿐

				// 1. 클라이언트가 송신한 num값을 읽는다.
				$num = requestValues("num");
				// 2. 그 값으로 해당하는 게시글을 읽는다
				$dao = new boardDao();
        $msg = $dao->getMsg($num);
    ?>


		<!-- 3. 그 정보를 이용해 html을 동적으로 생성한다. -->
		<div class="container">

			<h2>글 수정</h2>
			<form action="modify?num=<?= $msg["Num"]?>" method="post">
				<!-- 토큰은 form안에서 -->
			@csrf
			<div class="form-group"> <!-- title -->
			  <label for="title">제목:</label> 
			  <input type="text" class="form-control" id="title" name="title" value="<?= $msg["Title"]?>">
			</div>
			<div class="form-group"> <!-- writer -->
			  <label for="writer">작성자:</label>
			  <input type="text" class="form-control" id="writer" name="writer" value="<?= $member["name"] ?>" readonly>
			</div>
			<div class="form-group"> <!-- content -->
			  <label for="content">내용:</label>
			  <textarea id="content" name="content" rows="5" ><?= $msg["Content"]?></textarea>
			</div>	
			<button type="submit" class ="btn btn-success">글 수정</button>  <!-- submit, 글 수정 -->
			<button class ="btn btn-primary" onclick="location.href='board.php'">글 목록</button> <!-- 글 목록 -->
		</div>	
	</body>
</html>
