@extends('layouts.template')

@section('title')
	게시글 리스트
@endsection

@section('content')
@include('bbs/companySidebar')

    <div class="container">		
        <h2>회사연혁</h2>
        <hr>
        <!-- <img class="button_left" src="images/companyHistory.jpg" alt="피자" /> -->
    </div>

