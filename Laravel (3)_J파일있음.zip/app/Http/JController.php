<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Board;
	
class JController extends Controller
{

	public function index(Request $request) {

	$currentPage = $request->get("page");

    //$currentPage = requestValue("page");
    // http://localhost/bbs/board.php?page=-3
    if($currentPage < 1) 
		$currentPage = 1;
		

	$totalCount = Board::count();
	$totalMsgs = $totalCount;
	$startPage = 1;
	$endPage = 1;
	$totalPages = 1; 
	$prev = false;
	$next = false;
	$msgs = null; 
	
	$dao = new boardDao();

	// 집단함수, aggregate function
	// select count(*) from board;
	$totalCount = $dao->getTotalCount();

	if($totalCount > 0) {
	
			$startPage = floor(($currentPage-1)/10)*10+1;	
			$startRecord = ($currentPage-1)*10;
			/*$endPage = $startPage + 10 - 1;
			//$totalMsgs = $dao->getTotalCount();
			$totalPages = ceil($totalMsgs/10);
			if ($endPage > $totalPages)
				$endPage = $totalPages;

			$prev = false;
			$next = false;

			if ($startPage > 1) $prev = true;
	
				
			//$msgs = $dao->getManyMsgs();
			//$msgs = $dao->getMsgs4Page($startRecord, 10);
			*/
			$msgs = Board::orderBy('num','desc')->skip($startRecord)->take(10)->get();
		}

		return view('J.Jboard')
			       ->with('startPage', $startPage)
			       ->with('endPage', $endPage)
			       ->with('totalPages', $totalPages)
			       ->with('currentPage', $currentPage)
			       ->with('msgs', $msgs);

   }

   public function show(Request $request) {

		// 특정 글의 상세보기 

		/* 
			request에서 글의 id를 추출
			해당 번호의 글을 읽고, 조회 수 1 증가 
			읽은 글을 출력한다.

		*/
		$id = $request->id;
		$page = $request->page;

		// $msg = $dao->getMsg($id)
		$msg = Board::find($id);	// id 값이 레코드를 뽑아온다.
		// select * from boards where id=?
		$msg->update(["Hits"=>$msg->Hits+1]);
		//$dao->increaseHits($id);
		
   }

   public function create() {
	return view('J.Jwrite_form');
   }

   public function store(Request $request) { //post방식 /글쓰기처리


    $title = $request->title;
    $writer = $request->writer;
    $content = $request->content;

    $page = $request->page;

    if($title && $writer && $content){

		$this->validate($request,
			['title'=> 'required',   // 추가적인 것은 |를 해서 내용을 쓴다.
				'writer'=>'required',
				'content'=>'required']);	   

		$b = Board::create([
			'Title'=>$title,
			'Writer'=>$writer,
			'Content'=>$content,
		]);
		/*
			$bdao = new boardDao();
			$bdao->insertMsg($title, $writer, $content);
			// okGo("정상적으로 입력되었습니다.", "bbs?page=$page");
		*/

		return redirect('J?page=$page')->with('message',$title.'이 정상입력됨');
    }else{
		/*
			errorBack('모든 항목이 빈칸 없이 입력되어야 합니다.');
		*/
    }

   }

   public function edit(Request $request) { //글 수정 form

	/*
		1. 클라이언트가 송신한 num 값을 읽는다.
		2. 그 값으로 해당하는 게시글을 읽는다.
		3. 그 게시글 정보를 이용해 html을 동적으로 생성한다. 
	*/
		$num = $request->num;
		$page = $request->page;
		/*
		$dao = new boardDao();
		$row = $dao->getMsg($num);*/
		$row = Board::find($num);

		return view('J.Jmodify_form')->with('num',$num)->with('page',$page)->with('row',$row);
	
   }
   
   public function update(UpdateBoardRequest $request) { //post방식 /글수정처리

    $num = $request->num;
    $title = $request->title;
    $writer = $request->writer;
    $content = $request->content;

    $page = $request->page;

	/*
	$bdao = new boardDao();
	$bdao->updateMsg($num, $title, $writer, $content);
	//okGo("정상적으로 수정되었습니다.", "bbs?page=$page");
	*/
	$b=Board::find($num);
	$b->update([
		'Title'=>$title,
		'Writer'=>$writer,
		'Content'=>$content,
	]);
	return redirect('J?page=$page')->with('message',$num.'글이 정상수정됨');

   }

   public function destroy(Request $request) {

	$num = $request->num;
	$page = $request->page;

	/*
	$dao = new BoardDao();
	$dao->deleteMsg($num);
*/
	$b = Board::find($num);
	$b->delete();

	return redirect('J?page=$page')->with('message', $num . "번 글이 삭제되었습니다.");
   }


}
