<?php //1701140_변수정 ?>
<?php 
    session_start(); 	
?>
<!DOCTYPE html>
<html>
<head>
    <?php require("html_head.php") ?>
    <?php require("company_head.php") ?>
</head>
<body>
    <?php require("top_nav.php") ?>
    <?php require("nav.php") ?>
    <?php require("companySidebar.php") ?>
    <div class="container">		
        <h2>회사연혁</h2>
        <hr>
        <!-- <img class="button_left" src="images/companyHistory.jpg" alt="피자" /> -->
    </div>
    <?php require("footer.php") ?>
</body>
</html>
