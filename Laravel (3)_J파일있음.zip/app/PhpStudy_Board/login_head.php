
<style type="text/css">

    label {
        float:left;
        font-weight: 600;

    }

    input[type=text], input[type=password] {
        width: 25%;
        padding: 10px 10px;
        border: 2px solid skyblue;
        border-radius: 4px;
        box-sizing: border-box;
        margin-left:10%;
    }
    
    button[type=submit]{
        position:absolute;
        width: 100px;
        height: 80px;
        top: 38%;
        left: 47%;
    }


    footer {
        margin-top: 10%;
    }

</style>