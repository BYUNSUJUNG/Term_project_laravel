<style type="text/css">
    

    .container { /* boardBox */  /*height는 각각다름*/
        height: 700px;
        width: 60%; 
        background-color: white;
        border-radius: 20px;
        margin-top: 15%;
        margin-left: 30%;
        padding: 2%;
        box-shadow: 10px 10px 10px gray;
    }
    
    .menu {
        float:left;
    }

                
    footer {
        margin-top: 15%;
    }
</style>