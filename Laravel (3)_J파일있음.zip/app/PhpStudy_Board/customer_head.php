<style type="text/css">
    .container { /* boardBox */  /*height는 각각다름*/
        width: 60%; 
        background-color: white;
        border-radius: 20px;
        margin-top: 15%;
        margin-left: 30%;
        padding: 2%;
        box-shadow: 10px 10px 10px gray;
    }


    .pagination {
        margin-left: 35%;
    }

    .personBox {
        border: 2px solid #EAEAEA;
        padding: 25px;
    }

    .personTitle {
        font-size: 20px;
    }
                
    footer {
        margin-top: 12%;
    }
</style>