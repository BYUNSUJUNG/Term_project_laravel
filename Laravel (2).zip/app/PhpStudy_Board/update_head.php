
<style type="text/css">


    article {
        height: 40%;
    }

    footer {
        margin-top: 10%;
    }

</style>