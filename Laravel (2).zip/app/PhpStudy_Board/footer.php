<footer class="navbar navbar-expand-lg"  style="background-color: white;">
    <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
        <li class="nav-item">
            <a class="nav-link disabled" href="#">회사소개</a>
        </li>
        <li class="nav-item">
            <a class="nav-link disabled" href="#">홍보센터</a>
        </li>
        <li class="nav-item">
            <a class="nav-link disabled" href="#">채용정보</a>
        </li>
        <li class="nav-item">
            <a class="nav-link disabled" href="#">제휴카드</a>
        </li>
        <li class="nav-item">
            <a class="nav-link disabled" href="#">이동약관</a>
        </li>
        <li class="nav-item">
            <b><a class="nav-link" href="#">개인정보취급방침</a></b>
        </li>
    </ul>
</footer>