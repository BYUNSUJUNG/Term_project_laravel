<div class="list-group">
    <button type="button" class="list-group-item list-group-item-action active">
        CUSTOMER
    </button>
    <a href="customerNotices.php"><button type="button" class="list-group-item list-group-item-action">공지사항</button></a>
    <a href="customerCounselingService.php"><button type="button" class="list-group-item list-group-item-action">1:1문의</button></a>
    <a href="customerAdvertisingSchedule.php"><button type="button" class="list-group-item list-group-item-action">광고일정</button></a>
</div>