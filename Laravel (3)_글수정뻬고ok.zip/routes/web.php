<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Route::get('bbs', 'BBSController@index')->name('bbs');

Route::get('view/{id}', 'BBSController@show')->name('view');

Route::get('write_form','BBSController@create')->name('write_form');

Route::post('write', 'BBSController@store')->name('write');

Route::get('modify_form/{id}', 'BBSController@edit')->name('modify_form');

Route::patch('modify/{id}','BBSController@update')->name('modify');

Route::get('delete/{id}', 'BBSController@destroy')->name('delete');

Route::get('template', function(){
	return view('layouts.template');
});