<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class menu extends Model
{
    protected $filelable = ['menu','writer','title','file','content'];
}
