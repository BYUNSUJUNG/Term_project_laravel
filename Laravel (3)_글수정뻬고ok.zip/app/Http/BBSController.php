<?php

namespace App\Http\Controllers;

//use Illuminate\Http\Request;
use Request;

use App\menu;

use Illuminate\Support\Facades\Input;
use DB;

class BBSController extends Controller
{
   public function index(Request $request) {

	$menu = Menu::paginate(3);
	return view('bbs.board',compact('menu'));
	
	//return view('bbs.board',['todos'=>$todos]); // 위에랑 똑같


	/*
    require_once('boardDao.php');
    require_once('tools.php');

    $currentPage = requestValue("page");
    // http://localhost/bbs/board.php?page=-3
    if($currentPage < 1) 
    	$currentPage = 1;

	$dao = new boardDao();

	// 집단함수, aggregate function
	// select count(*) from board;
	$totalCount = $dao->getTotalCount();

	if($totalCount > 0) {
	
			$startPage = floor(($currentPage-1)/NUM_PAGE_LINKS)*NUM_PAGE_LINKS+1;	
			$endPage = $startPage + NUM_PAGE_LINKS - 1;
			$totalMsgs = $dao->getTotalCount();
			$totalPages = ceil($totalMsgs/NUM_LINES);
			if ($endPage > $totalPages)
				$endPage = $totalPages;

			$prev = false;
			$next = false;

			if ($startPage > 1) $prev = true;
	
			$startRecord = ($currentPage-1)*NUM_LINES;	
			//$msgs = $dao->getManyMsgs();
			$msgs = $dao->getMsgs4Page($startRecord, NUM_LINES);
		}

		return view('bbs.board')
			       ->with('startPage', $startPage)
			       ->with('endPage', $endPage)
			       ->with('totalPages', $totalPages)
			       ->with('currentPage', $currentPage)
			       ->with('msgs', $msgs);
*/
   }

   public function show($id) {

	$menu = Menu::find($id);
	return view('bbs.view',compact('menu'));

	
/*
		$id = requestValue("id");
		$page = requestValue("page");
		$dao = new boardDao();
		$msg = $dao->getMsg($id);	
		$dao->increaseHits($id);

		return view('bbs.view')->with('id', $id)->with('page', $page)->with('msg', $msg);
*/
   }

   public function create() { //글 쓰기 form

	return view('bbs.write_form');

   }

   public function store(Request $request) { //post방식 /글쓰기처리

	$menus = new Menu;

	$menus->menu = Input::get('menu');
	$menus->writer = Input::get('writer');
	$menus->title = Input::get('title');
	$menus->file = Input::get('file');
	$menus->content = Input::get('content');

	$menus->save();

	return redirect('bbs');

	/*
	$menu = Request::input('menu');
	$writer = Request::input('writer');
	$title = Request::input('title');
	$file = Request::input('file');
	$content = Request::input('content');
	//dd(Request::all());
	//방법1
	DB::insert('insert into menus(menu,writer,title,file,content) values(?,?,?,?,?)', [$menu,$writer,$title,$file,$content]);
	//방법2
	//DB::table('todos')->insert(['title'->$request->input('title')]);
	//방법3-1
	$todo = new Todo();
	$todo->title = $title;
	$todo->save(); 
*/
/*
	//방법3-2
	$todo = Todo::firstOrNew([
		'title'=>$request->input('title')
	]);
*/

	/*
	require_once('tools.php');
    require_once('boardDao.php');

    $title = requestValue('title');
    $writer = requestValue('writer');
    $content = requestValue('content');

    $page = requestValue('page');

    if($title && $writer && $content){
        $bdao = new boardDao();
        $bdao->insertMsg($title, $writer, $content);
		// okGo("정상적으로 입력되었습니다.", "bbs?page=$page");
		return redirect('bbs?page=$page')->with('message',$title.'이 정상입력됨');
    }else{
        errorBack('모든 항목이 빈칸 없이 입력되어야 합니다.');
    }
*/
   }

   public function edit($id) { //글 수정 form
	
	$menu = Menu::find($id);
	return view('bbs.modify_form',compact('menu'));

	/*
	require_once("boardDao.php");
	require_once("tools.php");
	/*
		1. 클라이언트가 송신한 num 값을 읽는다.
		2. 그 값으로 해당하는 게시글을 읽는다.
		3. 그 게시글 정보를 이용해 html을 동적으로 생성한다. 
	
		$num = requestValue("num");
    	$page = requestValue("page");
		$dao = new boardDao();
		$row = $dao->getMsg($num);

		return view('bbs.modify_form')->with('num',$num)->with('page',$page)->with('row',$row);
	*/
   }

   public function update(Request $request, $id) { //post방식 /글수정처리

	
	$menu = Menu::find($id);
	$menu->update(Request::all());
	return redirect('bbs');
	/*
    require_once('tools.php');
    require_once('boardDao.php');

    $num = requestValue('num');
    $title = requestValue('title');
    $writer = requestValue('writer');
    $content = requestValue('content');

    $page = requestValue('page');

    if($num && $title && $writer && $content){
        $bdao = new boardDao();
        $bdao->updateMsg($num, $title, $writer, $content);
		//okGo("정상적으로 수정되었습니다.", "bbs?page=$page");
		return redirect('bbs?page=$page')->with('message',$num.'글이 정상수정됨');
    }else{
        errorBack('모든 항목이 빈칸 없이 입력되어야 합니다.');
    }
*/
   }

   public function destroy($id) {
	$menu = Menu::find($id);
	$menu->delete();
	return redirect('bbs');
   }


}
